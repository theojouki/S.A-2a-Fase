import React, { useState, useEffect } from 'react';
import './Cadastro.css';

function Cadastro() {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    vicio: '',
  });

  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    const storedUsers = JSON.parse(localStorage.getItem('usuarios')) || [];
    setUsuarios(storedUsers);
  }, []);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const Cadastrar = () => {
    if (!formData.username || !formData.email || !formData.password || !formData.vicio) {
      alert('Por favor, preencha todos os campos!');
      return;
    }

    if (usuarios.some((user) => user.email === formData.email)) {
      alert('Este email já está cadastrado!');
      return;
    }

    const updatedUsers = [...usuarios, formData];
    setUsuarios(updatedUsers);

    localStorage.setItem('usuarios', JSON.stringify(updatedUsers));

    setFormData({ username: '', email: '', password: '', vicio: '' });

    alert('Cadastro realizado com sucesso!');
  };

  return (
    <div className="cadastro-container">
      <div className="left">
        <h1 className="text-h1">Bem-vindo a Wehab</h1>
        <p className="text-p">Que a sua reabilitação seja agradável e segura conosco</p>
      </div>
      <div className="right">
        <img className="image-logo" src="./images/Wehab.png" alt="Logo Wehab" />
        <input
          className="cadastro-inpt-field"
          type="text"
          name="username"
          value={formData.username}
          onChange={handleInputChange}
          placeholder="Nome de Usuário"
        />
        <input
          className="cadastro-inpt-field"
          type="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          placeholder="Email"
        />
        <input
          className="cadastro-inpt-field"
          type="password"
          name="password"
          value={formData.password}
          onChange={handleInputChange}
          placeholder="Senha"
        />
        <select
          className="cadastro-inpt-field"
          name="vicio"
          value={formData.vicio}
          onChange={handleInputChange}
        >
          <option value="" disabled>Selecione o vício a ser tratado</option>
          <option value="Álcool">Álcool</option>
          <option value="Cigarro">Cigarro</option>
          <option value="Cocaína">Cocaína</option>
          <option value="Crack">Crack</option>
          <option value="Jogos de Azar">Jogos de Azar</option>
          <option value="Maconha">Maconha</option>
          <option value="Pornografia">Pornografia</option>
          <option value="Remédios">Remédios</option>
        </select>
        <button className="cadastro-button" onClick={Cadastrar}>
          Cadastrar
        </button>
        <a href="/login" className="login-link">
          Já tem um cadastro? Clique aqui
        </a>
      </div>
    </div>
  );
}

export default Cadastro;