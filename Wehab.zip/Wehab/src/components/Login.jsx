import React, { useState } from 'react';
import './Login.css';

function Login() {
  const [loginData, setLoginData] = useState({
    username: '',
    password: '',
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setLoginData({ ...loginData, [name]: value });
  };

  const Logar = () => {
    const storedUsers = JSON.parse(localStorage.getItem('usuarios')) || [];

    const userExists = storedUsers.find(
      (user) => user.username === loginData.username && user.password === loginData.password
    );

    if (userExists) {
      alert(`Bem-vindo, ${loginData.username}!`);
    } else {
      alert('Usuário ou senha incorretos. Tente novamente.');
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <img className="image-logo" src="./images/Wehab.png" alt="Logo Wehab" />
        <input
          type="text"
          name="username"
          placeholder="Nome de Usuário"
          className="login-inpt-field"
          value={loginData.username}
          onChange={handleInputChange}
        />
        <input
          type="password"
          name="password"
          placeholder="Senha"
          className="login-inpt-field"
          value={loginData.password}
          onChange={handleInputChange}
        />
        <button type="button" className="login-button" onClick={Logar}>
          Login
        </button>
        <a href="/cadastro" className="register-link">
          Não tem um cadastro? Clique aqui
        </a>
      </div>
    </div>
  );
}

export default Login;