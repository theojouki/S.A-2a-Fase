import React from 'react'
import './Perfil.css'

function Perfil() {
  return (
    <div className='perfil-container'>
      <div class="sidebar">
      <h2>Home</h2>
      <ul>
        <li>🏆 Conquistas</li>
        <li>🔔 Notificações</li>
        <li>⚙️ Configurações</li>
      </ul>
    </div>
    
    </div>
  )
}

export default Perfil
